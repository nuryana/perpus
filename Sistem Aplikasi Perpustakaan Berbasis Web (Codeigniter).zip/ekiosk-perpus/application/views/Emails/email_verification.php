<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Email Verification</title>
    </head>
    <body>
        <p>Hello,</p>
        <p>
            Thank you for registering an account with us! Please
            <a href="<?php echo $link?>">verify your email address</a> to activate
            your account.
        </p>
    </body>
</html>
