<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Password Reset</title>
    </head>
    <body>
        <p>
        You have requested to reset your password. Please Click on
        the link below to continue.
        </p>
        <p>
            <a href="<?php echo $link?>">Reset my password</a>
        </p>
    </body>
</html>